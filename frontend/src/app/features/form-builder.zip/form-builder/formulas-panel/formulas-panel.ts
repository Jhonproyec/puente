import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormElement, FormRegion, Formula, FormulaResultFormat, FormulaType } from '../../../core/models/form-builder.model';
import { FormBuilderStateService } from '../../../core/services/form-builder-state.service';
import { FormulaService } from '../../../core/services/formula.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-formulas-panel',
  imports: [
    FormsModule,
    CommonModule
  ],
  templateUrl: './formulas-panel.html',
  styleUrl: './formulas-panel.css'
})
export class FormulasPanel {
   @Input() target!: FormElement | FormRegion;
  @Input() targetType!: 'element' | 'region' | null;
  @Output() backToProperties = new EventEmitter<void>();

  allNumericFields: FormElement[] = [];
  activeMode: 'quick' | 'custom' = 'quick'; // Opción A o B
  
  // ========== MODO RÁPIDO (Opción A) ==========
  newFormula: Partial<Formula> = {
    name: '',
    formulaType: 'sum',
    sourceFields: [],
    decimals: 2,
    resultFormat: {
      type: 'number',
      prefix: '',
      suffix: ''
    },
    weights: {}
  };

  formulaTypes: Array<{ value: string; label: string; description: string }> = [
    { value: 'sum', label: 'Suma', description: 'Suma todos los campos seleccionados' },
    { value: 'subtract', label: 'Resta', description: 'Resta el segundo campo del primero' },
    { value: 'multiply', label: 'Multiplicación', description: 'Multiplica todos los campos' },
    { value: 'divide', label: 'División', description: 'Divide el primer campo entre el segundo' },
    { value: 'average', label: 'Promedio', description: 'Calcula el promedio de los campos' },
    { value: 'pondering', label: 'Ponderación', description: 'Suma ponderada con pesos específicos' },
    { value: 'max', label: 'Máximo', description: 'Obtiene el valor máximo' },
    { value: 'min', label: 'Mínimo', description: 'Obtiene el valor mínimo' }
  ];

  resultFormatTypes = [
    { value: 'number', label: 'Número' },
    { value: 'percentage', label: 'Porcentaje' },
    { value: 'stars', label: 'Estrellas (Rating)' }
  ];

  // ========== MODO PERSONALIZADO (Opción B) ==========
  customFormula: string = '=';
  customFormulaValidation: { isValid: boolean; message: string } = { isValid: false, message: '' };
  customFormulaName: string = '';
  customFormulaFormat: string = 'number';
  customFormulaDecimals: number = 2;

  reservedFunctions = [
    { name: 'SUMA', description: 'SUMA(campo1+campo2)' },
    { name: 'RESTA', description: 'RESTA(campo1-campo2)' },
    { name: 'MULTI', description: 'MULTI(campo1*campo2)' },
    { name: 'DIV', description: 'DIV(campo1/campo2)' },
    { name: 'PROMEDIO', description: 'PROMEDIO(campo1,campo2,campo3)' },
    { name: 'MAX', description: 'MAX(campo1,campo2,campo3)' },
    { name: 'MIN', description: 'MIN(campo1,campo2,campo3)' }
  ];

  availableFieldNames: string[] = [];
  formulaPreviewValue: number = 0;

  constructor(
    private stateService: FormBuilderStateService,
    private formulaService: FormulaService
  ) { }

  ngOnInit(): void {
    this.loadAvailableFields();
  }

  /**
   * Carga los campos numéricos disponibles
   */
  loadAvailableFields(): void {
    this.allNumericFields = this.stateService.getAllElements()
      .filter(el => 
        (el.type === 'number' || el.type === 'rating') && 
        el.idFormElement !== (this.target as FormElement).idFormElement
      );

    this.availableFieldNames = this.allNumericFields.map(f => f.idFormElement || '');
  }

  onBackToProperties(): void {
    this.backToProperties.emit();
  }

  getTargetLabel(): string {
    if (this.targetType === 'region') {
      return `Región: ${(this.target as FormRegion).title}`;
    }
    return `Campo: ${(this.target as FormElement).label}`;
  }

  // ========== MÉTODOS MODO RÁPIDO ==========

  toggleSourceField(fieldId: string): void {
    const index = this.newFormula.sourceFields?.indexOf(fieldId) ?? -1;
    
    if (index > -1) {
      this.newFormula.sourceFields?.splice(index, 1);
    } else {
      if (!this.newFormula.sourceFields) {
        this.newFormula.sourceFields = [];
      }
      this.newFormula.sourceFields.push(fieldId);
    }

    if (this.newFormula.formulaType === 'pondering') {
      if (!this.newFormula.weights) {
        this.newFormula.weights = {};
      }
      if (index === -1) {
        this.newFormula.weights[fieldId] = 1;
      } else {
        delete this.newFormula.weights[fieldId];
      }
    }
  }

  isFieldSelected(fieldId: string): boolean {
    return this.newFormula.sourceFields?.includes(fieldId) ?? false;
  }

  onAddQuickFormula(): void {
    if (!this.newFormula.name || !this.newFormula.sourceFields || this.newFormula.sourceFields.length === 0) {
      alert('Por favor completa el nombre y selecciona al menos un campo');
      return;
    }

    const formula: Formula = {
      id: `formula_${Date.now()}`,
      name: this.newFormula.name || '',
      targetField: this.targetType === 'element' ? (this.target as FormElement).idFormElement! : '',
      formulaType: this.newFormula.formulaType as any,
      sourceFields: this.newFormula.sourceFields || [],
      resultFormat: this.newFormula.resultFormat || { type: 'number' },
      decimals: this.newFormula.decimals || 2,
      weights: this.newFormula.weights
    };

    if (this.targetType === 'element') {
      const element = this.target as FormElement;
      const updatedFormulas = [...(element.formulas || []), formula];
      this.stateService.updateElement(element.idFormElement!, { formulas: updatedFormulas });
    }

    this.resetQuickFormula();
  }

  removeFormula(index: number): void {
    if (this.targetType === 'element') {
      const element = this.target as FormElement;
      const updatedFormulas = element.formulas?.filter((_, i) => i !== index) || [];
      this.stateService.updateElement(element.idFormElement!, { formulas: updatedFormulas });
    }
  }

  private resetQuickFormula(): void {
    this.newFormula = {
      name: '',
      formulaType: 'sum',
      sourceFields: [],
      decimals: 2,
      resultFormat: {
        type: 'number',
        prefix: '',
        suffix: ''
      },
      weights: {}
    };
  }

  getTotalWeight(): number {
    if (!this.newFormula.weights) return 0;
    return Object.values(this.newFormula.weights).reduce((sum, w) => sum + w, 0);
  }

  normalizeWeights(): void {
    if (!this.newFormula.weights) return;
    
    const total = this.getTotalWeight();
    if (total === 0) return;

    const normalized: { [fieldId: string]: number } = {};
    for (const fieldId in this.newFormula.weights) {
      normalized[fieldId] = this.newFormula.weights[fieldId] / total;
    }
    this.newFormula.weights = normalized;
  }

  // ========== MÉTODOS MODO PERSONALIZADO ==========

  /**
   * Valida la fórmula personalizada en tiempo real
   */
  onCustomFormulaChange(): void {
    this.customFormulaValidation = this.formulaService.validateFormulaExpression(
      this.customFormula,
      this.availableFieldNames
    );

    // Preview del valor si la fórmula es válida
    if (this.customFormulaValidation.isValid) {
      this.updateFormulaPreview();
    }
  }

  /**
   * Actualiza el preview de la fórmula
   */
  updateFormulaPreview(): void {
    // Crear valores de prueba
    const testValues: { [key: string]: number } = {};
    this.availableFieldNames.forEach(fieldName => {
      testValues[fieldName] = Math.random() * 100;
    });

    this.formulaPreviewValue = this.formulaService.evaluateCustomFormula(
      this.customFormula,
      testValues
    );
  }

  /**
   * Inserta una función reservada en el editor
   */
  insertFunction(funcName: string): void {
    const cursorPos = (document.querySelector('.custom-formula-input') as HTMLTextAreaElement)?.selectionStart || this.customFormula.length;
    const before = this.customFormula.substring(0, cursorPos);
    const after = this.customFormula.substring(cursorPos);
    this.customFormula = `${before}${funcName}()${after}`;
    this.onCustomFormulaChange();
  }

  /**
   * Inserta una referencia de campo
   */
  insertField(fieldId: string): void {
    const cursorPos = (document.querySelector('.custom-formula-input') as HTMLTextAreaElement)?.selectionStart || this.customFormula.length;
    const before = this.customFormula.substring(0, cursorPos);
    const after = this.customFormula.substring(cursorPos);
    this.customFormula = `${before}{${fieldId}}${after}`;
    this.onCustomFormulaChange();
  }

  /**
   * Agrega una fórmula personalizada
   */
  onAddCustomFormula(): void {
    if (!this.customFormulaValidation.isValid) {
      alert('La fórmula contiene errores. Corrígela antes de guardar.');
      return;
    }

    if (!this.customFormulaName) {
      alert('Por favor asigna un nombre a la fórmula');
      return;
    }

    const formula: Formula = {
      id: `formula_${Date.now()}`,
      name: this.customFormulaName,
      targetField: this.targetType === 'element' ? (this.target as FormElement).idFormElement! : '',
      formulaType: 'custom',
      customExpression: this.customFormula,
      sourceFields: this.formulaService.getFieldsFromExpression(this.customFormula),
      resultFormat: {
        type: this.customFormulaFormat as any,
        prefix: this.customFormulaFormat === 'percentage' ? '' : '',
        suffix: this.customFormulaFormat === 'percentage' ? '%' : ''
      },
      decimals: this.customFormulaDecimals
    };

    if (this.targetType === 'element') {
      const element = this.target as FormElement;
      const updatedFormulas = [...(element.formulas || []), formula];
      this.stateService.updateElement(element.idFormElement!, { formulas: updatedFormulas });
    }

    this.resetCustomFormula();
  }

  /**
   * Resetea el editor personalizado
   */
  private resetCustomFormula(): void {
    this.customFormula = '=';
    this.customFormulaName = '';
    this.customFormulaFormat = 'number';
    this.customFormulaDecimals = 2;
    this.customFormulaValidation = { isValid: false, message: '' };
  }

  /**
   * Obtiene el nombre amigable de un campo
   */
  getFieldLabel(fieldId: string): string {
    const field = this.allNumericFields.find(f => f.idFormElement === fieldId);
    return field?.label || fieldId;
  }

  /**
   * Obtiene la descripción de una fórmula
   */
  getFormulaDescription(formula: Formula): string {
    if (formula.formulaType === 'custom' && formula.customExpression) {
      return this.formulaService.getCustomFormulaDescription(formula.customExpression);
    }
    return `${formula.name}`;
  }

  /**
   * Obtiene las fórmulas existentes del elemento seleccionado
   */
  getExistingFormulas(): Formula[] {
    if (this.targetType === 'element') {
      const element = this.target as FormElement;
      return element.formulas || [];
    }
    return [];
  }
}

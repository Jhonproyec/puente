import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { ViewMode } from '../../core/models/form-builder.model';
import { CatalogService } from '../../core/services/catalog.service';
import { FormBuilderStateService } from '../../core/services/form-builder-state.service';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { StructurePanel } from './structure-panel/structure-panel/structure-panel';
import { FormPreview } from './form-preview/form-preview/form-preview';
import { FormProperties } from './form-properties/form-properties/form-properties';

@Component({
  selector: 'app-form-create',
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    StructurePanel,
    FormPreview,
    FormProperties
  ],
  templateUrl: './form-create.html',
  styleUrl: './form-create.css',
  standalone: true
})
export class FormCreate implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  formName = 'Nuevo Formulario';
  currentView: ViewMode = 'structure';

  constructor(
    public stateService: FormBuilderStateService,
    private catalogService: CatalogService
  ) { }

  ngOnInit(): void {
    // Suscribirse a cambios en el nombre del formulario
    this.stateService.formDefinition$
      .pipe(takeUntil(this.destroy$))
      .subscribe(form => {
        this.formName = form.name;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onFormNameChange(name: string): void {
    this.stateService.updateFormName(name);
  }

  changeView(view: ViewMode): void {
    this.currentView = view;
  }

  onExportForm(): void {
    const json = this.stateService.exportFormDefinition();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.formName || 'formulario'}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  onSaveForm(): void {
    const formData = this.stateService.formDefinition;
    console.log('Formulario guardado:', formData);
    alert(`Formulario "${formData.name}" guardado exitosamente!\n\nRevisa la consola para ver el JSON.`);
    console.log(JSON.stringify(formData, null, 2));

    // En producción, aquí harías una petición HTTP:
    // this.formService.saveForm(formData).subscribe(...);
  }

  onLoadCatalogs(): void {
    this.catalogService.getAvailableCatalogs()
      .subscribe(catalogs => {
        console.log('Catálogos disponibles:', catalogs);
        alert('Catálogos cargados desde el backend (simulado).\nRevisa la consola.');
      });
  }

}

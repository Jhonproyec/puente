import { Component, OnDestroy, OnInit } from '@angular/core';
import { combineLatest, Subject, takeUntil } from 'rxjs';
import { FormElement, FormRegion, PanelMode } from '../../../../core/models/form-builder.model';
import { FormBuilderStateService } from '../../../../core/services/form-builder-state.service';
import { CatalogService } from '../../../../core/services/catalog.service';
import { ElementProperties } from '../element-properties/element-properties/element-properties';
import { ActionsPanel } from '../actions-panel/actions-panel';
import { ValidationsPanel } from '../validations-panel/validations-panel';
import { FormulasPanel } from '../../formulas-panel/formulas-panel';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-form-properties',
  imports: [
    ElementProperties,
    ActionsPanel,
    ValidationsPanel,
    FormulasPanel,
    CommonModule
  ],
  templateUrl: './form-properties.html',
  styleUrl: './form-properties.css',
  standalone: true,
})
export class FormProperties implements OnInit, OnDestroy{
  private destroy$ = new Subject<void>();

  panelMode: PanelMode = 'properties';
  selectedElement: FormElement | FormRegion | null = null;
  selectedType: 'element' | 'region' | null = null;

  constructor(
    public stateService: FormBuilderStateService,
    public catalogService: CatalogService
  ){}

  ngOnInit(): void {
    // Observar cambios en el panel mode y elemento seleccionado
    combineLatest([
      this.stateService.panelMode$,
      this.stateService.selectedElement$,
      this.stateService.selectedType$,
      this.stateService.formDefinition$
    ]).pipe(takeUntil(this.destroy$))
    .subscribe(([model, elementId, type]) => {
      this.panelMode = model;
      this.selectedType = type,
      this.selectedElement = this.stateService.getSelectedElementData();
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  backToProperties():void{
    this.stateService.setPanelMode('properties');
  }

  isElementType():boolean{
    return this.selectedType === 'element';
  }

  isRegionType():boolean{
    return this.selectedType === 'region';
  }

}

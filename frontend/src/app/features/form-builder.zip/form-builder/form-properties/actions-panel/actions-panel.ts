import { Component, Input, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { ActionType, DynamicAction, FormElement, FormRegion } from '../../../../core/models/form-builder.model';
import { FormBuilderStateService } from '../../../../core/services/form-builder-state.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-actions-panel',
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './actions-panel.html',
  styleUrl: './actions-panel.css',
  standalone: true
})
export class ActionsPanel implements OnInit {
  @Input() target!: FormElement | FormRegion;
  @Input() targetType!: 'element' | 'region' | null;
  @Output() backToProperties = new EventEmitter<void>();


  allElements: FormElement[] = [];
  newAction = {
    triggerField: '',
    type: 'show_if_equals' as ActionType,
    value: ''
  };

  constructor(
    private stateService: FormBuilderStateService
  ) { }

  ngOnInit(): void {
    // Obtener todos los elementos disponibles (excepto el actual si es elemento)
    this.allElements = this.stateService.getAllElements();
  }


  onBackToProperties(): void {
    this.backToProperties.emit();
  }

  getTargetLabel(): string {
    if (this.targetType === 'region') {
      return `Región: ${(this.target as FormRegion).title}`;
    }
    return `Campo: ${(this.target as FormElement).label}`;
  }

  needsValue(): boolean {
    return !['show_if_filled', 'show_if_empty'].includes(this.newAction.type);
  }

  addAction(): void {
    if (!this.newAction.triggerField) {
      alert('Selecciona un campo');
      return;
    }

    if (this.needsValue() && !this.newAction.value) {
      alert('Ingresa un valor de comparación');
      return;
    }

    // Buscar label del campo trigger
    const triggerElement = this.allElements.find(el => el.idFormElement === this.newAction.triggerField);
    const triggerLabel = triggerElement?.label || '';

    const action: DynamicAction = {
      triggerField: this.newAction.triggerField,
      triggerLabel: triggerLabel,
      type: this.newAction.type,
      value: this.newAction.value
    };

    // Agregar acción al target
    const updatedActions = [...(this.target.actions || []), action];

    if (this.targetType === 'region') {
      const region = this.target as FormRegion;
      this.stateService.formDefinition.regions =
        this.stateService.formDefinition.regions.map(r =>
          r.idFormRegion === region.idFormRegion ? { ...r, actions: updatedActions } : r
        );
    } else {
      const element = this.target as FormElement;
      this.stateService.updateElement(element.idFormElement!, { actions: updatedActions });
    }

    // Reset form
    this.newAction = {
      triggerField: '',
      type: 'show_if_equals',
      value: ''
    };

    // Forzar actualización
    this.stateService['formDefinitionSubject'].next(this.stateService.formDefinition);
  }

  removeAction(index: number): void {
    const updatedActions = this.target.actions.filter((_, i) => i !== index);

    if (this.targetType === 'region') {
      const region = this.target as FormRegion;
      this.stateService.formDefinition.regions =
        this.stateService.formDefinition.regions.map(r =>
          r.idFormRegion === region.idFormRegion ? { ...r, actions: updatedActions } : r
        );
    } else {
      const element = this.target as FormElement;
      this.stateService.updateElement(element.idFormElement!, { actions: updatedActions });
    }

    // Forzar actualización
    this.stateService['formDefinitionSubject'].next(this.stateService.formDefinition);
  }

  getActionDescription(action: DynamicAction): string {
    const descriptions: Record<string, string> = {
      'show_if_equals': `Mostrar si ${action.triggerLabel} es igual a "${action.value}"`,
      'show_if_not_equals': `Mostrar si ${action.triggerLabel} es diferente de "${action.value}"`,
      'show_if_filled': `Mostrar si ${action.triggerLabel} tiene valor`,
      'show_if_empty': `Mostrar si ${action.triggerLabel} está vacío`,
      'show_if_greater': `Mostrar si ${action.triggerLabel} es mayor que ${action.value}`,
      'show_if_less': `Mostrar si ${action.triggerLabel} es menor que ${action.value}`,
      'hide_if_equals': `Ocultar si ${action.triggerLabel} es igual a "${action.value}"`,
      'hide_if_not_equals': `Ocultar si ${action.triggerLabel} es diferente de "${action.value}"`
    };
    return descriptions[action.type] || 'Acción desconocida';
  }

}


import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormElement, ValidationRule, ValidationType } from '../../../../core/models/form-builder.model';
import { FormBuilderStateService } from '../../../../core/services/form-builder-state.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-validations-panel',
  imports: [
    FormsModule
  ],
  templateUrl: './validations-panel.html',
  styleUrl: './validations-panel.css',
  standalone: true
})
export class ValidationsPanel implements OnInit {
  @Input() element!: FormElement;
  @Output() backToProperties = new EventEmitter<void>();
  validationOptions: Array<{ value: ValidationType; label: string }> = [];



  newValidation = {
    type: '' as ValidationType | '',
    value: '',
    message: ''
  }

  constructor(
    private stateService: FormBuilderStateService
  ) { }

  ngOnInit() {
    this.validationOptions = this.getValidationOptions();
  }

  onBackToProperties() {
    this.backToProperties.emit();
  }

  getValidationOptions(): Array<{ value: ValidationType; label: string }> {
    const type = this.element.type;

    const optionsByType: Record<string, Array<{ value: ValidationType; label: string }>> = {
      text: [
        { value: 'min_length', label: 'Longitud mínima' },
        { value: 'max_length', label: 'Longitud máxima' },
        { value: 'pattern', label: 'Patrón (Regex)' },
        { value: 'no_special_chars', label: 'Sin caracteres especiales' },
        { value: 'only_letters', label: 'Solo letras' },
        { value: 'only_numbers', label: 'Solo números' }
      ],
      textarea: [
        { value: 'min_length', label: 'Longitud mínima' },
        { value: 'max_length', label: 'Longitud máxima' },
        { value: 'pattern', label: 'Patrón (Regex)' }
      ],
      number: [
        { value: 'min_value', label: 'Valor mínimo' },
        { value: 'max_value', label: 'Valor máximo' },
        { value: 'integer_only', label: 'Solo enteros' },
        { value: 'positive_only', label: 'Solo positivos' }
      ],
      email: [
        { value: 'email_format', label: 'Formato de email válido' },
        { value: 'email_domain', label: 'Dominio específico' }
      ],
      date: [
        { value: 'min_date', label: 'Fecha mínima' },
        { value: 'max_date', label: 'Fecha máxima' },
        { value: 'date_today', label: 'Fecha máxima: hoy' },
        { value: 'date_future', label: 'Solo fechas futuras' },
        { value: 'date_past', label: 'Solo fechas pasadas' },
        { value: 'age_min', label: 'Edad mínima' },
        { value: 'age_max', label: 'Edad máxima' }
      ],
      select: [
        { value: 'min_selections', label: 'Mínimo de selecciones' },
        { value: 'max_selections', label: 'Máximo de selecciones' }
      ],
      checkbox: [
        { value: 'min_selections', label: 'Mínimo de selecciones' },
        { value: 'max_selections', label: 'Máximo de selecciones' }
      ],
      camera: [
        { value: 'max_file_size', label: 'Tamaño máximo (MB)' },
        { value: 'image_dimensions', label: 'Dimensiones mínimas' }
      ]
    };

    return optionsByType[type] || [];
  }

  needsValue(): boolean {
    const noValueTypes: ValidationType[] = [
      'email_format', 'no_special_chars', 'only_letters', 'only_numbers',
      'integer_only', 'positive_only', 'date_today', 'date_future', 'date_past'
    ];
    return this.newValidation.type !== '' && !noValueTypes.includes(this.newValidation.type as ValidationType);
  }

  getValueLabel(): string {
    const labels: Partial<Record<ValidationType, string>> = {
      'min_length': 'Cantidad mínima de caracteres',
      'max_length': 'Cantidad máxima de caracteres',
      'pattern': 'Expresión regular',
      'min_value': 'Valor mínimo',
      'max_value': 'Valor máximo',
      'email_domain': 'Dominio permitido (ej: gmail.com)',
      'min_date': 'Fecha mínima (YYYY-MM-DD)',
      'max_date': 'Fecha máxima (YYYY-MM-DD)',
      'age_min': 'Edad mínima',
      'age_max': 'Edad máxima',
      'min_selections': 'Mínimo de opciones',
      'max_selections': 'Máximo de opciones',
      'max_file_size': 'Tamaño máximo en MB',
      'image_dimensions': 'Ancho x Alto (ej: 800x600)'
    };
    return labels[this.newValidation.type as ValidationType] || 'Valor';
  }

  addValidation(): void {
    if (!this.newValidation.type) {
      alert('Selecciona un tipo de validación');
      return;
    }

    if (this.needsValue() && !this.newValidation.value) {
      alert('Ingresa un valor para la validación');
      return;
    }

    const validation: ValidationRule = {
      type: this.newValidation.type as ValidationType,
      value: this.newValidation.value,
      message: this.newValidation.message || this.getDefaultMessage()
    };

    const updatedValidations = [...(this.element.validations || []), validation];
    this.stateService.updateElement(this.element.idFormElement!, { validations: updatedValidations });

    // Reset form
    this.newValidation = {
      type: '',
      value: '',
      message: ''
    };
  }

  removeValidation(index: number): void {
    const updatedValidations = this.element.validations.filter((_, i) => i !== index);
    this.stateService.updateElement(this.element.idFormElement!, { validations: updatedValidations });
  }

  getValidationDescription(validation: ValidationRule): string {
    const descriptions: Partial<Record<ValidationType, string>> = {
      'min_length': `Mínimo ${validation.value} caracteres`,
      'max_length': `Máximo ${validation.value} caracteres`,
      'pattern': `Patrón: ${validation.value}`,
      'no_special_chars': 'Sin caracteres especiales',
      'only_letters': 'Solo letras',
      'only_numbers': 'Solo números',
      'min_value': `Valor mínimo: ${validation.value}`,
      'max_value': `Valor máximo: ${validation.value}`,
      'integer_only': 'Solo números enteros',
      'positive_only': 'Solo números positivos',
      'email_format': 'Formato de email válido',
      'email_domain': `Dominio: ${validation.value}`,
      'min_date': `Fecha mínima: ${validation.value}`,
      'max_date': `Fecha máxima: ${validation.value}`,
      'date_today': 'Fecha máxima: hoy',
      'date_future': 'Solo fechas futuras',
      'date_past': 'Solo fechas pasadas',
      'age_min': `Edad mínima: ${validation.value} años`,
      'age_max': `Edad máxima: ${validation.value} años`,
      'min_selections': `Mínimo ${validation.value} opciones`,
      'max_selections': `Máximo ${validation.value} opciones`,
      'max_file_size': `Máximo ${validation.value} MB`,
      'image_dimensions': `Dimensiones mínimas: ${validation.value}`
    };
    return descriptions[validation.type] || 'Validación desconocida';
  }

  private getDefaultMessage(): string {
    const type = this.newValidation.type as ValidationType;
    const value = this.newValidation.value;

    const messages: Partial<Record<ValidationType, string>> = {
      'min_length': `Debe tener al menos ${value} caracteres`,
      'max_length': `No puede exceder ${value} caracteres`,
      'pattern': 'Formato inválido',
      'no_special_chars': 'No se permiten caracteres especiales',
      'only_letters': 'Solo se permiten letras',
      'only_numbers': 'Solo se permiten números',
      'min_value': `El valor mínimo es ${value}`,
      'max_value': `El valor máximo es ${value}`,
      'integer_only': 'Solo se permiten números enteros',
      'positive_only': 'Solo se permiten números positivos',
      'email_format': 'Ingresa un email válido',
      'email_domain': `El email debe ser de ${value}`,
      'min_date': `La fecha mínima es ${value}`,
      'max_date': `La fecha máxima es ${value}`,
      'date_today': 'La fecha no puede ser futura',
      'date_future': 'Selecciona una fecha futura',
      'date_past': 'Selecciona una fecha pasada',
      'age_min': `Debe tener al menos ${value} años`,
      'age_max': `No puede tener más de ${value} años`,
      'min_selections': `Selecciona al menos ${value} opciones`,
      'max_selections': `Selecciona máximo ${value} opciones`,
      'max_file_size': `El archivo no puede exceder ${value} MB`,
      'image_dimensions': `La imagen debe tener al menos ${value} píxeles`
    };

    return messages[type] || 'Campo inválido';
  }

}

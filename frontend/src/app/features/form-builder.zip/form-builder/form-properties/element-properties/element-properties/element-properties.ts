import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { CatalogOption, ElementType, FormElement, FormRegion } from '../../../../../core/models/form-builder.model';
import { Subject, takeUntil } from 'rxjs';
import { FormBuilderStateService } from '../../../../../core/services/form-builder-state.service';
import { CatalogService } from '../../../../../core/services/catalog.service';
import { NotificationService } from '../../../../../core/services/notification.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-element-properties',
  imports: [
    FormsModule
  ],
  templateUrl: './element-properties.html',
  styleUrl: './element-properties.css',
  standalone: true
})
export class ElementProperties implements OnInit, OnDestroy {
  @Input() element!: FormElement | FormRegion;
  @Input() elementType: 'element' | 'region' | null = null;
  private destroy$ = new Subject<void>();

  availableCatalogs: Array<{ id: string; name: string }> = [];
  catalogOption: CatalogOption[] = [];
  loadingCatalog: boolean = false;
  newOptionText: string = '';

  elementTypes: Array<{ value: ElementType; label: string }> = [
    { value: 'text', label: 'Texto' },
    { value: 'number', label: 'Numérico' },
    { value: 'email', label: 'Email' },
    { value: 'date', label: 'Fecha' },
    { value: 'textarea', label: 'Área de Texto' },
    { value: 'select', label: 'Select' },
    { value: 'radio', label: 'Radio Button' },
    { value: 'checkbox', label: 'Checkbox' },
    { value: 'camera', label: 'Cámara (Foto)' }
  ];

  constructor(
    private stateService: FormBuilderStateService,
    private catalogService: CatalogService,
    private notificationService: NotificationService
  ) { }

  ngOnInit(): void {
    this.catalogService.getAvailableCatalogs()
      .pipe(takeUntil(this.destroy$))
      .subscribe(catalogs => {
        this.availableCatalogs = catalogs;
      });

    // Si el elemento tiene un catálogo seleccionado, cargar sus opciones
    if (this.isElement() && this.asElement().catalogType) {
      this.loadCatalogOptions(this.asElement().catalogType!);
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  isElement(): boolean {
    return this.elementType === 'element';
  }

  isRegion(): boolean {
    return this.elementType === 'region';
  }

  asElement(): FormElement {
    return this.element as FormElement;
  }

  asRegion(): FormRegion {
    return this.element as FormRegion;
  }

  showOptionsSelector(): boolean {
    if (!this.isElement()) return false;
    const el = this.asElement();
    return el.type == 'select' || el.type == 'radio' || el.type === 'checkbox';
  }

  showMultipleSelection(): boolean {
    if (!this.isElement()) return false;
    const el = this.asElement();
    console.log(el.type);
    return el.type === 'select' || el.type === 'checkbox';
  }

  showPlaceholder(): boolean {
    if (!this.isElement()) return false;
    const el = this.asElement();
    return el.type !== 'camera';
  }

  updateRegionTitle(title: string): void {
    if (this.isRegion()) {
      this.stateService.updateRegionTitle(this.asRegion().idFormRegion!, title);
    }
  }

  updateElementProperty(property: keyof FormElement, value: any): void {
    if (!this.isElement()) return;

    const element = this.asElement();
    const updates: Partial<FormElement> = { [property]: value };

    // Si cambia el tipo inicializar opciones
    if (property === 'type') {
      const newType = value as ElementType;
      if ((newType === 'select' || newType === 'radio' || newType === 'checkbox') &&
        element.options.length === 0
      ) {
        updates.options = ['Opción 1', 'Opción 2'];
        updates.selectedOptions = ['Opción 1', 'Opción 2'];
      }
    }

    this.stateService.updateElement(element.idFormElement!, updates);
  }

  // METODO DE CATÁLOGOS
  onCatalogChange(catalogId: string): void {
    if (!this.isElement()) return;

    const element = this.asElement();

    if (catalogId) {
      this.loadCatalogOptions(catalogId);
      this.stateService.updateElement(element.idFormElement!, { catalogType: catalogId });
    } else {
      // Sin catálogo, modo manual
      this.catalogOption = [];
      this.stateService.updateElement(element.idFormElement!, {
        catalogType: null,
        options: element.options.length > 0 ? element.options : ['Opción 1', 'Opción 2'],
        selectedOptions: element.selectedOptions.length > 0 ? element.selectedOptions : ['Opción 1', 'Opción 2']
      });
    }
  }

  loadCatalogOptions(catalogId: string): void {
    this.loadingCatalog = true;
    this.catalogService.getCatalogOptions(catalogId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (options) => {
          this.catalogOption = options;
          if (this.isElement()) {
            const optionValues = options.map(opt => opt.label);
            this.stateService.updateElement(this.asElement().idFormElement!, {
              options: optionValues,
              selectedOptions: optionValues
            });
          }
          this.loadingCatalog = false;
        },
        error: (error) => {
          console.error("Error al cargar los catálogos", error);
          this.notificationService.showError("Error al cargar los catálogos");
          this.loadingCatalog = false;
        }
      })
  }


  toggleOption(option: string, checked: boolean): void {
    if (!this.isElement()) return;

    const element = this.asElement();
    let selectedOptions = [...element.selectedOptions];

    if (checked) {
      if (!selectedOptions.includes(option)) {
        selectedOptions.push(option);
      }
    } else {
      selectedOptions = selectedOptions.filter(opt => opt !== option);
    }

    this.stateService.updateElement(element.idFormElement!, { selectedOptions });
  }

  toggleAllOptions(): void {
    if (!this.isElement()) return;

    const element = this.asElement();
    const availableOptions = element.catalogType ? this.catalogOption.map(opt => opt.label) : element.options;

    if (element.selectedOptions.length === availableOptions.length) {
      // Deseleccionar todos
      this.stateService.updateElement(element.idFormElement!, { selectedOptions: [] });
    } else {
      // Seleccionar todos
      this.stateService.updateElement(element.idFormElement!, { selectedOptions: availableOptions });
    }
  }

  addCustomOption(): void {
    if (!this.isElement() || !this.newOptionText.trim()) return;

    const element = this.asElement();
    const newOption = this.newOptionText.trim();

    if (!element.options.includes(newOption)) {
      const updatedOptions = [...element.options, newOption];
      const updatedSelectedOptions = [...element.selectedOptions, newOption];

      this.stateService.updateElement(element.idFormElement!, {
        options: updatedOptions,
        selectedOptions: updatedSelectedOptions,
        catalogType: null // Cambiar a modo manual
      });

      this.newOptionText = '';
      this.catalogOption = []; // Limpiar catálogo cargado
    }
  }

  isOptionSelected(option: string): boolean {
    if (!this.isElement()) return false;
    return this.asElement().selectedOptions.includes(option);
  }

  getAvailableOptions(): string[] {
    if (!this.isElement()) return [];
    const element = this.asElement();
    return element.catalogType ? this.catalogOption.map(opt => opt.label) : element.options;
  }

}

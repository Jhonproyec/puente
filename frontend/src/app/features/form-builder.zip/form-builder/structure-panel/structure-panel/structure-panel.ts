import { Component, Input, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { FormDefinition, FormElement, FormRegion, ViewMode } from '../../../../core/models/form-builder.model';
import { Subject, takeUntil } from 'rxjs';
import { FormBuilderStateService } from '../../../../core/services/form-builder-state.service';
import { NotificationService } from '../../../../core/services/notification.service';
import { ConfirmDialogService } from '../../../../core/services/confirm-dialog.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-structure-panel',
  imports: [
    FormsModule
  ],
  templateUrl: './structure-panel.html',
  styleUrl: './structure-panel.css',
  standalone: true
})
export class StructurePanel implements OnInit, OnDestroy {

  @Input() currentView: ViewMode = 'structure';
  @Output() viewChange = new EventEmitter<ViewMode>();

  private destroy$ = new Subject<void>();

  formDefinition: FormDefinition | null = null;
  selectedElementId: string | null = null;
  selectedRegionId: string | null = null;

  constructor(
    public stateService: FormBuilderStateService,
    private notificationService: NotificationService,
    private confirmService: ConfirmDialogService
  ) { }

  ngOnInit(): void {
    // Suscribirse al estado del formulario
    this.stateService.formDefinition$
      .pipe(takeUntil(this.destroy$))
      .subscribe(form => {
        this.formDefinition = form;
      });

    // Suscribirse a la selección actual
    this.stateService.selectedElement$
      .pipe(takeUntil(this.destroy$))
      .subscribe(elementId => {
        this.selectedElementId = elementId;
      });

    this.stateService.selectedRegion$
      .pipe(takeUntil(this.destroy$))
      .subscribe(regionId => {
        this.selectedRegionId = regionId;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onChangeView(view: ViewMode): void {
    this.viewChange.emit(view);
  }

  onAddRegion(): void {
    const region = this.stateService.addRegion();
    this.stateService.selectRegion(region.idFormRegion!);
  }

  onAddElement(): void {
    const element = this.stateService.addElement();
    if (element) {
      const region = this.stateService.getRegionByElementId(element.idFormElement!);
      // console.log(region);
      if (region) {
        this.stateService.selecteElement(element.idFormElement!, region.idFormRegion!);
      }
    } else {
      this.notificationService.showError("No existe una región creada");
    }
  }

  onSelectRegion(regionId: string): void {
    this.stateService.selectRegion(regionId);
  }

  onSelectElement(elementId: string, regionId: string): void {
    console.log(elementId, regionId);
    this.stateService.selecteElement(elementId, regionId);
  }

  onDeleteRegion(regionId: string): void {
    this.confirmService.confirmDelete("¿Está seguro de eliminar esta región?").subscribe(confirm => {
      if (confirm) {
        this.stateService.deleteRegion(regionId);
      }
    })
  }

  onDeleteElement(elementId: string): void {
    this.confirmService.confirmDelete("¿Está seguro de eliminar este campo?").subscribe(confirm => {
      if (confirm) {
        this.stateService.deleteElement(elementId);
      }
    })
  }

  onOpenActions(targetId: string, targetType: 'element' | 'region', regionId?: string): void {
    if (targetType === 'element' && regionId) {
      this.stateService.selecteElement(targetId, regionId);
    } else {
      this.stateService.selectRegion(targetId);
    }
    this.stateService.setPanelMode('actions');
  }

  onOpenValidations(elementId: string, regionId: string): void {
    this.stateService.selecteElement(elementId, regionId);
    this.stateService.setPanelMode('validations');
  }

  onOpenProperties(targetId: string, targetType: 'element' | 'region', regionId?: string): void {
    console.log(targetId, targetType, regionId);
    if (targetType === 'element' && regionId) {
      this.stateService.selecteElement(targetId, regionId);
    } else {
      this.stateService.selectRegion(targetId);
    }
    this.stateService.setPanelMode('properties');
  }

  // drop(event: CdkDragDrop<FormElement[]>): void {
  // Implementar lógica de drag & drop si es necesario
  // Por ahora se maneja de forma simple
  // }

  isElementSelected(elementId: string): boolean {
    return this.selectedElementId === elementId;
  }

  isRegionSelected(regionId: string): boolean {
    return this.selectedRegionId === regionId;
  }

  hasActions(item: FormRegion | FormElement): boolean {
    return item.actions && item.actions.length > 0;
  }

  hasValidations(element: FormElement): boolean {
    return element.validations && element.validations.length > 0;
  }

  getAllActions(): Array<{ region?: FormRegion; element?: FormElement; actions: any[] }> {
    if (!this.formDefinition) return [];

    const result: Array<{ region?: FormRegion; element?: FormElement; actions: any[] }> = [];

    this.formDefinition.regions.forEach(region => {
      if (region.actions && region.actions.length > 0) {
        result.push({ region, actions: region.actions });
      }

      region.elements.forEach(element => {
        if (element.actions && element.actions.length > 0) {
          result.push({ element, actions: element.actions });
        }
      });
    });

    return result;
  }

  getAllValidations(): Array<{ element: FormElement; validations: any[] }> {
    if (!this.formDefinition) return [];

    const result: Array<{ element: FormElement; validations: any[] }> = [];

    this.formDefinition.regions.forEach(region => {
      region.elements.forEach(element => {
        if (element.validations && element.validations.length > 0) {
          result.push({ element, validations: element.validations });
        }
      });
    });

    return result;
  }

  getActionDescription(action: any): string {
    const descriptions: Record<string, string> = {
      'show_if_equals': `Mostrar si ${action.triggerLabel} es igual a "${action.value}"`,
      'show_if_not_equals': `Mostrar si ${action.triggerLabel} es diferente de "${action.value}"`,
      'show_if_filled': `Mostrar si ${action.triggerLabel} tiene valor`,
      'show_if_empty': `Mostrar si ${action.triggerLabel} está vacío`,
      'show_if_greater': `Mostrar si ${action.triggerLabel} es mayor que ${action.value}`,
      'show_if_less': `Mostrar si ${action.triggerLabel} es menor que ${action.value}`,
      'hide_if_equals': `Ocultar si ${action.triggerLabel} es igual a "${action.value}"`,
      'hide_if_not_equals': `Ocultar si ${action.triggerLabel} es diferente de "${action.value}"`
    };
    return descriptions[action.type] || 'Acción desconocida';
  }

  getValidationDescription(validation: any): string {
    const descriptions: Record<string, string> = {
      'min_length': `Mínimo ${validation.value} caracteres`,
      'max_length': `Máximo ${validation.value} caracteres`,
      'pattern': `Patrón: ${validation.value}`,
      'no_special_chars': `Sin caracteres especiales`,
      'only_letters': `Solo letras`,
      'only_numbers': `Solo números`,
      'min_value': `Valor mínimo: ${validation.value}`,
      'max_value': `Valor máximo: ${validation.value}`,
      'integer_only': `Solo números enteros`,
      'positive_only': `Solo números positivos`,
      'email_format': `Formato de email válido`,
      'email_domain': `Dominio: ${validation.value}`,
      'min_date': `Fecha mínima: ${validation.value}`,
      'max_date': `Fecha máxima: ${validation.value}`,
      'date_today': `Fecha máxima: hoy`,
      'date_future': `Solo fechas futuras`,
      'date_past': `Solo fechas pasadas`,
      'age_min': `Edad mínima: ${validation.value} años`,
      'age_max': `Edad máxima: ${validation.value} años`,
      'min_selections': `Mínimo ${validation.value} opciones`,
      'max_selections': `Máximo ${validation.value} opciones`,
      'max_file_size': `Máximo ${validation.value} MB`,
      'image_dimensions': `Dimensiones mínimas: ${validation.value}`
    };
    return descriptions[validation.type] || 'Validación desconocida';
  }

  onOpenFormulas(elementId: string, regionId: string): void {
    this.stateService.selecteElement(elementId, regionId);
    this.stateService.setPanelMode('formulas');
  }


}

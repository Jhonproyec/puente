import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { FormDefinition, FormElement, FormRegion } from '../../../../core/models/form-builder.model';
import { FormBuilderStateService } from '../../../../core/services/form-builder-state.service';

@Component({
  selector: 'app-form-preview',
  imports: [],
  templateUrl: './form-preview.html',
  styleUrl: './form-preview.css',
  standalone: true
})
export class FormPreview implements OnInit, OnDestroy{
  private destroy$ = new Subject<void>();
  formDefinition: FormDefinition | null = null;

  constructor(
    private stateService: FormBuilderStateService
  ){}


  ngOnInit():void{
    this.stateService.formDefinition$
      .pipe(takeUntil(this.destroy$))
      .subscribe(form => {
        this.formDefinition = form;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  hasActions(item: FormRegion | FormElement):boolean{
    return item.actions && item.actions.length >0;
  }

  getPlaceholder(element: FormElement):string{
    if(element.type === 'select'){
      return element.placeholder || 'Seleccionar una opción';
    }
    return element.placeholder
  }

}
